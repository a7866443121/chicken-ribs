<template>
    <ul>
        <router-link tag='li' to='home'>首页</router-link>
        <router-link tag='li' to='city'>城市页面</router-link>
        <router-link tag='li' to='msite'>商店列表</router-link>
        <router-link tag='li' to='shop'>商铺详情</router-link>
        <router-link tag='li' to='search'>搜索</router-link>
        <router-link tag='li' to='login'>登陆</router-link>
        <router-link tag='li' to='checkout'>确认订单</router-link>
        <router-link tag='li' to='forget'>忘记密码</router-link>
        <router-link tag='li' to='profile'>个人信息</router-link>
        <router-link tag='li' to='order'>订单列表</router-link>
        <router-link tag='li' to='vipcard'>会员卡</router-link>
    </ul>
</template>

<script>

export default {
    
}

</script>

<style lang="scss" scoped>
    
</style>
